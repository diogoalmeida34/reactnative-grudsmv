interface BotaoSecundarioProps {
  titulo: string;
  onPress: () => void;
}