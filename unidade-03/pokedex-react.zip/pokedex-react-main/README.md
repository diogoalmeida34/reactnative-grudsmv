# 📘 Pokédex - Fundamentos de React com TypeScript

Este projeto é uma Pokédex desenvolvida na **Aula 03 da matéria de Desenvolvimento para Dispositivos Móveis (GRUDSMV)**, para praticar os fundamentos do **React com TypeScript**, integrando a **PokéAPI** para consumir dados de diferentes Pokémons.

---

## 🚀 Funcionalidades

- 🔍 Busca de Pokémons por nome
- 📦 Consumo da [PokéAPI](https://pokeapi.co)
- 💡 Componente `PokeCard` para exibição dos dados
- ⭐ Favoritar/desfavoritar Pokémons
- 💾 Armazenamento dos favoritos com `localStorage`
- 🎨 Estilização separada com CSS modularizado
- 🖥️ Layout responsivo e centralizado
- 🔁 Suporte à busca de múltiplos Pokémons em sequência
- 🧠 Log no console sempre que um Pokémon for carregado com sucesso

---

## 🧪 Tecnologias Utilizadas

- [React](https://reactjs.org/)
- [TypeScript](https://www.typescriptlang.org/)
- [Vite](https://vitejs.dev/) <!-- ou substitua se for CRA -->
- [PokéAPI](https://pokeapi.co)
- CSS Modules
- Hooks: `useState`, `useEffect`

---

## ⚙️ Como executar o projeto
1. **Clone o repositório**
   ```bash
   git clone https://github.com/seu-usuario/pokedex-react-typescript.git

2. **Instale as dependências**
   ```bash
    npm install

3. **Execute o projeto**
   ```bash
    npm run dev

4. **Abra no navegador**
http://localhost:5173

_Obs.: ⚠️ Certifique-se de que está usando Node.js 16+ e que o Vite está instalado (ou substitua pelos comandos do CRA se for o caso)._

---

## 📜 Licença

Este projeto está licenciado sob a **MIT License**.

---

## 🌐 API

**PokéAPI**: API pública usada para obter informações dos Pokémons.  
🔗 [https://pokeapi.co](https://pokeapi.co)
