import Pokedex from "./components/Pokedex";

export default function App() {
  return (
    <div>
      <Pokedex />
    </div>
  );
}