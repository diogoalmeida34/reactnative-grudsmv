// Interface base
interface Usuario {
  id: number;
  nome: string;
  email: string;
  senha: string;
}

// Utility Types
type UsuarioSemSenha = Omit<Usuario, "senha">;
type UsuarioAtualizacao = Partial<Usuario>;

// Simulando um banco de dados de usuários
const usuarios: Usuario[] = [
  { id: 1, nome: "Alice", email: "alice@email.com", senha: "1234" },
  { id: 2, nome: "Bob", email: "bob@email.com", senha: "5678" },
  { id: 3, nome: "Diogo", email: "diogo@email.com", senha: "9101" },
];

// Função para exibir perfil (sem mostrar a senha)
function exibirPerfil(u: UsuarioSemSenha): void {
  console.log("Perfil do usuário:");
  console.log("ID:", u.id);
  console.log("Nome:", u.nome);
  console.log("Email:", u.email);
}

// Função para atualizar dados de um usuário (parcialmente)
function atualizarUsuario(id: number, dados: UsuarioAtualizacao): void {
  const usuario = usuarios.find((u) => u.id === id);

  if (!usuario) {
    console.error("Usuário não encontrado!");
    return;
  }

  Object.assign(usuario, dados); // Atualiza os campos fornecidos
  console.log(`Usuário com ID ${id} atualizado:`, usuario);
}

// Testes
const usuarioParaExibir: UsuarioSemSenha = {
  id: 1,
  nome: "Alice",
  email: "alice@email.com",
};

exibirPerfil(usuarioParaExibir);

atualizarUsuario(1, { nome: "Alice Silva", email: "alice.novo@email.com" });