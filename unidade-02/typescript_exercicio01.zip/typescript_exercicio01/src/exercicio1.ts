// Definindo a interface Livro
interface Livro {
  titulo: string;
  autor: string;
  ano: number;
  disponivel: boolean;
}

// Criando um array de livros
const biblioteca: Livro[] = [
  {
    titulo: "O Senhor dos Anéis",
    autor: "J.R.R. Tolkien",
    ano: 1954,
    disponivel: true,
  },
  {
    titulo: "1984",
    autor: "George Orwell",
    ano: 1949,
    disponivel: false,
  },
  {
    titulo: "Dom Casmurro",
    autor: "Machado de Assis",
    ano: 1899,
    disponivel: true,
  },
  {
    titulo: "As coisas que você só vê quando desacelera",
    autor: "Haemin Sunim",
    ano: 2017,
    disponivel: false,
  },
];

// Função que lista apenas os títulos dos livros disponíveis
function listarTitulosDisponiveis(livros: Livro[]): string[] {
  return livros
    .filter((livro) => livro.disponivel === true)
    .map((livro) => livro.titulo);
}

// Função que lista apenas os títulos dos livros indisponíveis
function listarTitulosIndisponiveis(livros: Livro[]): string[] {
  return livros
    .filter((livro) => livro.disponivel === false)
    .map((livro) => livro.titulo);
}

console.log("*** BIBLIOTECA ***\n");
// Exemplo de saída esperada: ["O Senhor dos Anéis", "Dom Casmurro"]
console.log("Livros Disponiveis", listarTitulosDisponiveis(biblioteca), '\n');
// Exemplo de saída esperada: ["1984", "As coisas que você só vê quando desacelera"]
console.log("Livros Indisponiveis", listarTitulosIndisponiveis(biblioteca));