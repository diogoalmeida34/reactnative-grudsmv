// Definindo os tipos literais e união
type Sucesso = { tipo: "sucesso"; dados: string[] };
    type Erro = { tipo: "erro"; mensagem: string };
    type Resultado = Sucesso | Erro;

// Função que exibe o resultado com base no tipo
function exibirResultado(r: Resultado): void {
  if (r.tipo === "sucesso") {
    console.log("Dados recebidos:");
    r.dados.forEach((item) => console.log("- " + item));
  } else if (r.tipo === "erro") {
    console.error("Erro:", r.mensagem);
  }
}

// Exemplos de uso
const resultado1: Resultado = { tipo: "sucesso", dados: ["Item 1", "Item 2"] };
const resultado2: Resultado = { tipo: "erro", mensagem: "Algo deu errado!" };

exibirResultado(resultado1); // Deve mostrar os dados
exibirResultado(resultado2); // Deve mostrar a mensagem de erro