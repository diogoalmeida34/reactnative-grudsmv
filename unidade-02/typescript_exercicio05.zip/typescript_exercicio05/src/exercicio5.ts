// Interface que define as props esperadas
interface PropsBotao {
  titulo: string;
  ativo?: boolean; // Opcional
}

// Função que simula a renderização de um botão com base nas props
function renderizarBotao({ titulo, ativo = true }: PropsBotao): string {
  return ativo ? `[ ${titulo} ]` : `( ${titulo} )`;
}

// Testes com diferentes valores

// Ativo (implícito como true)
const botao1 = renderizarBotao({ titulo: "Salvar" });
console.log(botao1); // [ Salvar ]

// Ativo (explicitamente true)
const botao2 = renderizarBotao({ titulo: "Enviar", ativo: true });
console.log(botao2); // [ Enviar ]

// Inativo (ativo: false)
const botao3 = renderizarBotao({ titulo: "Cancelar", ativo: false });
console.log(botao3); // ( Cancelar )
