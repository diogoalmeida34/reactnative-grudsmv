// Função genérica para obter o primeiro item de uma lista
function obterPrimeiro<T>(lista: T[]): T {
  if (lista.length === 0) {
    throw new Error("A lista está vazia.");
  }
  return lista[0];
}

// string[]
const nomes = ["Alice", "Bob", "Carlos"];
const primeiroNome = obterPrimeiro(nomes);
console.log("Primeiro nome:", primeiroNome); // string

// number[]
const numeros = [10, 20, 30];
const primeiroNumero = obterPrimeiro(numeros);
console.log("Primeiro número:", primeiroNumero); // number

interface Produto {
  nome: string;
  preco: number;
}

const produtos: Produto[] = [
  { nome: "Notebook", preco: 2500 },
  { nome: "Mouse", preco: 100 },
  { nome: "Teclado", preco: 75 },
];

const primeiroProduto = obterPrimeiro(produtos);

// Exibindo o primeiro produto
console.log("\n*** Primeiro produto ***\n");
console.log("Item: ", primeiroProduto.nome, "\nValor:", "R$", primeiroProduto.preco);
