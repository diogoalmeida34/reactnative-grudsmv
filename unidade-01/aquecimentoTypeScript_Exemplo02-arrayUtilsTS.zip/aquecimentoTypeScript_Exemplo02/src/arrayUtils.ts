// Função para remover duplicatas de um array
export const unique = <T>(arr: T[]): T[] => [...new Set(arr)];

// Função para agrupar um array de objetos por uma chave específica
export const groupBy = <T, K extends keyof T>(arr: T[], key: K): Record<string, T[]> =>
  arr.reduce((acc, obj) => {
    const groupKey = String(obj[key]); // Garantir que a chave seja do tipo string
    (acc[groupKey] = acc[groupKey] || []).push(obj);
    return acc;
  }, {} as Record<string, T[]>);

// Função para somar um valor específico de cada objeto de um array
export const sumBy = <T, K extends keyof T>(arr: T[], key: K): number =>
  arr.reduce((total, obj) => total + (Number(obj[key]) || 0), 0);
