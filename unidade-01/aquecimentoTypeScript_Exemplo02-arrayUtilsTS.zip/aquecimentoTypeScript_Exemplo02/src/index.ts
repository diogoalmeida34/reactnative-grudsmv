// Importando as funções do arquivo arrayUtils.js
import { unique, groupBy, sumBy } from './arrayUtils';

// Testando a função unique
console.log("Testando a função unique:");
console.log(unique([1, 2, 2]));  // Esperado: [1, 2]
console.log(unique([1, 2, 3, 4, 4, 5]));  // Esperado: [1, 2, 3, 4, 5]
console.log(unique(['a', 'b', 'a', 'c', 'b']));  // Esperado: ['a', 'b', 'c']

console.log("\n"); // Quebra de linha para separar os testes

// Testando a função groupBy
console.log("Testando a função groupBy:");
const dados = [
  { tipo: 'A', nome: 'Item 1' },
  { tipo: 'B', nome: 'Item 2' },
  { tipo: 'A', nome: 'Item 3' }
];
console.log(groupBy(dados, 'tipo'));  
// Esperado: { A: [ { tipo: 'A', nome: 'Item 1' }, { tipo: 'A', nome: 'Item 3' } ], B: [ { tipo: 'B', nome: 'Item 2' } ] }

const pessoas = [
  { nome: 'João', idade: 30 },
  { nome: 'Maria', idade: 22 },
  { nome: 'José', idade: 30 }
];
console.log(groupBy(pessoas, 'idade'));  
// Esperado: { 30: [ { nome: 'João', idade: 30 }, { nome: 'José', idade: 30 } ], 22: [ { nome: 'Maria', idade: 22 } ] }

console.log("\n");

// Testando a função sumBy
console.log("Testando a função sumBy:");
const vendas = [
  { valor: 100 },
  { valor: 200 },
  { valor: 150 }
];
console.log(sumBy(vendas, 'valor'));  
// Esperado: 450

const produtos = [
  { preco: 10 },
  { preco: 25 },
  { preco: 15 }
];
console.log(sumBy(produtos, 'preco'));  
// Esperado: 50

console.log("\n");
