// Função utilitária para capitalizar a primeira letra do nome do Pokémon
function capitalizar(str: string): string {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

function sairComErro(mensagem: string): never {
  console.log(mensagem);
  process.exit(1);
  throw new Error("Encerrado.");
}

// Captura o argumento passado via terminal (nome ou ID do Pokémon)
const idOuNome = process.argv[2];

// Se nenhum argumento for passado, exibe uma mensagem e encerra
if (!idOuNome) {
  sairComErro("❗ Por favor, forneça o nome ou ID de um Pokémon.");
}

// Função principal para buscar e exibir dados do Pokémon
async function buscarPokemon(pokemon: string): Promise<void> {
  const url = `https://pokeapi.co/api/v2/pokemon/${pokemon}`;

  try {
    const response = await fetch(url);

    if (!response.ok) {
      if (response.status === 404) {
        console.log("❌ Pokémon não encontrado!");
      } else {
        console.log(`⚠️ Erro inesperado: ${response.statusText}`);
      }
      return;
    }

    const data = await response.json();

    const nome = capitalizar(data.name);
    const altura = data.height / 10; // decímetros → metros
    const peso = data.weight / 10;   // hectogramas → kg
    const tipos = data.types
      .map((tipo: any) => capitalizar(tipo.type.name))
      .join(", ");

    console.log(`${nome} – ${altura} m – ${peso} kg – ${tipos}`);

  } catch (erro) {
    console.log("⚠️ Erro de rede. Tente novamente.");
  }
}

// Executa a função principal com o argumento do terminal
buscarPokemon(idOuNome);
