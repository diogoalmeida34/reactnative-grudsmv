export type RootStackParamList = {
  Pokedex: undefined; 
  PokemonDetails: { pokemonId: number }; 
};